﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EmpProjUsingFiles
{
    class SearchFromFileQ2:ProjectDetails
    {
        
        public string answer;
        public void SearchFromDEPTFile()
        {
            
        Console.WriteLine("Enter department name to search");
            string key = Console.ReadLine();                                    //Collecting key from user
            string filename2 = @"D:\EMPFilesProj\DeptData.txt";
            StreamReader reader = new StreamReader(filename2);
            string recordD;
            string found;
            try
            {
                recordD = reader.ReadLine();
                while (recordD != null)                                         //Checking for empty record
                {
                    if (recordD.Contains(key))                                  //Search for key
                    {
                        found = recordD.Trim();                                 //to remove unwanted spaces
                        answer = found.Substring(0, 5);                         //looking for substring from index 0 and length 5 from 0.
                        SearchFromEMPFile(answer);                              //passing key to Employee file to see the results
                    }
                    
                    recordD = reader.ReadLine();                                //Assigning back to next line to check
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                reader.Close();                                                 //At the end close has to be done.
            }
            
        }

        public void SearchFromEMPFile(string key)
        {
            string filename1 = @"D:\EMPFilesProj\empData.txt";
            StreamReader reader = new StreamReader(filename1);                  //Key passed by department file
            string recordE;
            try
            {
                recordE = reader.ReadLine();
                while (recordE!=null)                                           //Checking for empty record
                {
                    if (recordE.Contains(key))                                  //Search for key
                    {
                        Console.WriteLine(recordE);                             //printing specified results
                    }
                    recordE = reader.ReadLine();                                //Assigning back to next line to check
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                reader.Close();
            }
        }
    }
}
