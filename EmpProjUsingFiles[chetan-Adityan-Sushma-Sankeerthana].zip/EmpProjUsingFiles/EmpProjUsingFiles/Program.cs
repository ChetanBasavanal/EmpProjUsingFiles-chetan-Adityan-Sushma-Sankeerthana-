﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EmpProjUsingFiles
{
    class Program
    {
        static void Main(string[] args)
        {
            List<EmployeeDetails> emprec = new List<EmployeeDetails>();             //List to collect the data
            List<DeptDetails> dptrec = new List<DeptDetails>();
            List<ProjectDetails> projrec = new List<ProjectDetails>();
            string filename1 = @"D:\EMPFilesProj\empData.txt";                      //Location of the files
            string filename2 = @"D:\EMPFilesProj\DeptData.txt";
            string filename3 = @"D:\EMPFilesProj\ProjData.txt";
            int ch;
            //string key;

            do
            {
                Console.WriteLine("============================");
                Console.WriteLine("1. Insert Employee Details");                    //Menu driven
                Console.WriteLine("2. Insert Department Details");
                Console.WriteLine("3. Insert Project Details");
                Console.WriteLine("4. Display and write on Employee Details File");
                Console.WriteLine("5. Display and write on Department Details File");
                Console.WriteLine("6. Display and write Project Details File");
                Console.WriteLine("7. Read from file Q2");
                Console.WriteLine("8. Read from file Q3");
                Console.WriteLine("9. Read from file Q4");
                Console.WriteLine("0. Exit");
                Console.WriteLine("============================");

                Console.WriteLine("Enter your Choice");
                ch = int.Parse(Console.ReadLine());
                Console.WriteLine("----------------------------");

                switch (ch)
                {
                    case 1:
                        EmployeeDetails emp = new EmployeeDetails();                //Data collection
                        emp.EmployeeDetailsInput();
                        emprec.Add(emp);
                        break;

                    case 2:
                        DeptDetails Dpt = new DeptDetails();
                        Dpt.DeptDetailsInput();
                        dptrec.Add(Dpt);
                        break;
                        
                    case 3:
                        ProjectDetails proj = new ProjectDetails();
                        proj.ProjectDetailsInput();
                        projrec.Add(proj);
                        break;

                    case 4:
                        
                        if(emprec==null)
                            Console.WriteLine("NO DATA FOUND");
                        else
                        {
                            try
                            {
                                using (StreamWriter W = new StreamWriter(filename1))
                                {
                                    foreach (EmployeeDetails e in emprec)                       //writing into file using StreamWriter and also displaying
                                    {
                                        e.displayE();
                                        
                                        W.Write(e.OutputdataE() + "\n");
                                    }
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);           
                            }
                        }
                        break;

                    case 5:
                        
                        if(dptrec==null)
                            Console.WriteLine("NO DATA FOUND");
                        else
                        {
                            try
                            {
                                using (StreamWriter W = new StreamWriter(filename2))
                                {
                                    foreach(DeptDetails d in dptrec)                            //writing into file using StreamWriter and also displaying
                                    {
                                        d.displayD();
                                        
                                        W.Write(d.outputDataD() + "\n");
                                    }
                                }
                            }
                            catch(Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }
                        }
                        break;

                    case 6:
                        
                        if(projrec==null)
                            Console.WriteLine("NO DATA FOUND");
                        else
                        {
                            try
                            {
                                using(StreamWriter W= new StreamWriter(filename3))
                                {
                                    foreach(ProjectDetails p in projrec)                        //writing into file using StreamWriter and also displaying
                                    {
                                        p.displayP();
                                        
                                        W.Write(p.outputDataP()+ "\n");
                                    }
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }
                        }
                        break;

                    case 7:
                        SearchFromFileQ2 S = new SearchFromFileQ2();                           //Query 2 call up 
                        S.SearchFromDEPTFile();
                        break;

                    case 8:
                        SearchFromFileQ3 Q = new SearchFromFileQ3();                          //Query 3 call up
                        Q.SearchFromPROJFile();
                        break;

                    case 9:
                        SearchFromFileQ4 P = new SearchFromFileQ4();                         //Query 4 call up
                        break;

                    case 0:                                                                 //exit
                        break;


                }
            } while (ch != 0);
        }
    }
}
