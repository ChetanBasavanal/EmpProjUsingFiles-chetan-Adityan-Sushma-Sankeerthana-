﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EmpProjUsingFiles
{
    class SearchFromFileQ3:SearchFromFileQ2
    {
        public void SearchFromPROJFile()
        {
            int p1;
            string p2;
            Console.WriteLine("Enter the Manager EmpID");
            int k1 = int.Parse(Console.ReadLine());                         //User Input 
            string key = k1.ToString();                                     //Converting to string to pass into text file
            string filename3 = @"D:\EMPFilesProj\ProjData.txt";
            StreamReader reader = new StreamReader(filename3);
            string recordP;
            try
            {
                recordP = reader.ReadLine();
                while (recordP != null)                                     //Checking for empty record
                {
                    if (recordP.Contains(key))                              //Search for key
                    {
                        p1 = (recordP.IndexOf("|"))+1;                      //Searched for index and added +1 to print from next character
                        p2 = recordP.Trim().Substring(p1, 5);               //first we trim it and then find substring of index p1 and length 5 from p1
                        Console.WriteLine("Department ID: "+p2);
                        SearchFromEMPFile(p2);                              //passing value to employee file
                        
                    }
                    recordP = reader.ReadLine();                            //Assigning back to next line to check
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                reader.Close();                                             //At the end close has to be done, else it causes problem
            }
        }
    }
}
