﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EmpProjUsingFiles
{
    class SearchFromFileQ4:SearchFromFileQ3
    {
        public string key;
        public SearchFromFileQ4()
        {
            Console.WriteLine("Enter the Department Name: ");                   //User Input
            key = Console.ReadLine();

            string filename2 = @"D:\EMPFilesProj\DeptData.txt";
            StreamReader reader = new StreamReader(filename2);
            string recordD;
            string found;
            try
            {
                recordD = reader.ReadLine();
                while (recordD != null)                                         //Checking for empty record
                {
                    if (recordD.Contains(key))                                  //Search for key
                    {
                        found = recordD.Trim();                                 //trim the unwanted spaces
                        answer = found.Substring(0, 5);                         //search for substring index 0 and length 5 from index
                        //Console.WriteLine(answer);
                        SearchFromPROJFile(answer);                             //passing value to Project file
                    }
                    recordD = reader.ReadLine();                                //Assigning back to next line to check
                }


            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                reader.Close();                                                 //At the end close has to be done, else it causes problem
            }
        }

        public void SearchFromPROJFile(string key)                              //Takes input from above
        {
            string filename3 = @"D:\EMPFilesProj\ProjData.txt";
            StreamReader reader = new StreamReader(filename3);
            string recordP;
            try
            {
                recordP = reader.ReadLine();
                while (recordP != null)                                         //Checking for empty record
                {
                    if (recordP.Contains(key))                                  //Search for key
                    {
                        Console.WriteLine(recordP);                             //printing specified result
                    }
                    recordP = reader.ReadLine();                                //Assigning back to next line to check
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                reader.Close();                                                 //At the end close has to be done.
            }
        }
    }
}
