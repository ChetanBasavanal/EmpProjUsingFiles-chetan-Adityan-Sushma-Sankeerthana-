﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EmpProjUsingFiles
{
    class Program
    {
        static void Main(string[] args)
        {
            string filename1 = @"D:\EMPFilesProj\empData.txt";                      //Location of the files
            string filename2 = @"D:\EMPFilesProj\DeptData.txt";
            string filename3 = @"D:\EMPFilesProj\ProjData.txt";
            int ch;
            
            do
            {
                Console.WriteLine("============================");
                Console.WriteLine("1. Insert Employee Details on File");                    //Menu driven
                Console.WriteLine("2. Insert Department Details on File");
                Console.WriteLine("3. Insert Project Details on File");
                Console.WriteLine("4. Display Employee Details File");
                Console.WriteLine("5. Display Department Details File");
                Console.WriteLine("6. Display Project Details File");
                Console.WriteLine("7. Read from file Q2");
                Console.WriteLine("8. Read from file Q3");
                Console.WriteLine("9. Read from file Q4");
                Console.WriteLine("0. Exit");
                Console.WriteLine("============================");

                Console.WriteLine("Enter your Choice");
                ch = int.Parse(Console.ReadLine());
                Console.WriteLine("----------------------------");

                switch (ch)
                {
                    case 1:
                        EmployeeDetails emp = new EmployeeDetails();                //Data collection
                        emp.EmployeeDetailsInput();
                       // var file = new FileInfo(filename1);
                        
                        try
                        {
                            using (StreamWriter W = new StreamWriter(filename1, true))
                            {
                                W.Write(emp.OutputdataE() + "\n");
                            }
                            
                        }
                        catch(Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                       
                        break;

                    case 2:
                        DeptDetails Dpt = new DeptDetails();
                        Dpt.DeptDetailsInput();
                        try
                        {
                            using (StreamWriter W = new StreamWriter(filename2, true))
                            {
                                W.Write(Dpt.outputDataD() + "\n");
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        
                        break;
                        
                    case 3:
                        ProjectDetails proj = new ProjectDetails();
                        proj.ProjectDetailsInput();
                        try
                        {
                            using (StreamWriter W = new StreamWriter(filename3, true))
                            {
                                W.Write(proj.outputDataP() + "\n");
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        
                        break;

                    case 4:
                        StreamReader R1 = new StreamReader(filename1);
                        if (R1.ReadLine()==null)
                            Console.WriteLine("NO DATA FOUND");
                        else
                        { 
                            try
                            {
                                string read = R1.ReadLine();
                                while (read!=null)
                                {
                                    Console.WriteLine(read);
                                    read = R1.ReadLine();
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);           
                            }
                            finally
                            {
                                R1.Close();
                            }
                        }
                        break;

                    case 5:
                        StreamReader R2 = new StreamReader(filename2);
                        if (R2.ReadLine()==null)
                            Console.WriteLine("NO DATA FOUND");
                        else
                        {
                            try
                            {
                                string read = R2.ReadLine();
                                while (read != null)
                                {
                                    Console.WriteLine(read);
                                    read = R2.ReadLine();
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }
                            finally
                            {
                                R2.Close();
                            }
                        }
                        break;

                    case 6:
                        StreamReader R3 = new StreamReader(filename3);
                        if (R3.ReadLine()==null)
                            Console.WriteLine("NO DATA FOUND");
                        else
                        {
                            try
                            {
                                string read = R3.ReadLine();
                                while (read != null)
                                {
                                    Console.WriteLine(read);
                                    read = R3.ReadLine();
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }
                            finally
                            {
                                R3.Close();
                            }
                        }
                        break;

                    case 7:
                        SearchFromFileQ2 S = new SearchFromFileQ2();                           //Query 2 call up 
                        S.SearchFromDEPTFile();
                        break;

                    case 8:
                        SearchFromFileQ3 Q = new SearchFromFileQ3();                          //Query 3 call up
                        Q.SearchFromPROJFile();
                        break;

                    case 9:
                        SearchFromFileQ4 P = new SearchFromFileQ4();                         //Query 4 call up
                        break;

                    case 0:                                                                 //exit
                        break;


                }
            } while (ch != 0);
        }
    }
}
