﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EmpProjUsingFiles
{
    class DeptDetails:EmployeeDetails
    {
        public string deptName;
        public int DeptId,noofProj;

        public void DeptDetailsInput()
        {
            Console.WriteLine("Enter Department ID");
            DeptId = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Department Name");                 //Data Collection from user
            deptName = Console.ReadLine();

            Console.WriteLine("Enter no of Projects assigned to the department");
            noofProj = int.Parse(Console.ReadLine());
        }

        public void displayD()
        {
            Console.WriteLine(DeptId.ToString().PadLeft(10)+"|"+deptName.PadLeft(10)+"|"+noofProj.ToString().PadLeft(10)+"|");
        }

        public string outputDataD()                 //Inorder to push data to file
        {
            return (DeptId.ToString().PadLeft(10) + "|" + deptName.PadLeft(10) + "|" + noofProj.ToString().PadLeft(10) + "|");
        }
    }
}
